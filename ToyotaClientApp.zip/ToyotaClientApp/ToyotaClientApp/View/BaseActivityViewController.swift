//
//  BaseActivityViewController.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 22/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

//class BaseActivityViewController:UINavigationBar{
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//
//        navigationController?.navigationBar.barTintColor = #colorLiteral(red: 0.5843137503, green: 0.8235294223, blue: 0.4196078479, alpha: 1)
//        navigationController?.navigationBar.tintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
//    }
//
//}


//class base: UINavigationBar{
//    
//    override var barTintColor: UICol
//}
