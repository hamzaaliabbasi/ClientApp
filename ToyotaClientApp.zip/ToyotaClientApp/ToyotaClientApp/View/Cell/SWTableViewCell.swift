//
//  SWTableViewCell.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 29/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit


class SWTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var LogoImage: UIImageView!
    
    @IBOutlet weak var LogoLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
//        LogoImage.layer.borderWidth = 1
//        LogoImage.layer.masksToBounds = false
//        LogoImage.layer.borderColor = UIColor.black.cgColor
//        LogoImage.layer.cornerRadius = LogoImage.frame.height/2
//        LogoImage.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
