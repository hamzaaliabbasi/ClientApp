//
//  CarSettingTableViewCell.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 20/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class CarSettingTableViewCell: UITableViewCell {
    //MARK: - Outlets
    @IBOutlet weak var Alert_label: UILabel?
    
    @IBOutlet weak var Alert_Switch: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
