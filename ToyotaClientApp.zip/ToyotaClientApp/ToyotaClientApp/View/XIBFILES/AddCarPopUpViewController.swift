//
//  AddCarPopUpViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 19/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
class AddCarPopUpViewController: UIView {

    @IBOutlet weak var txt_Email: SkyFloatingLabelTextField!
    
    @IBOutlet weak var Btn_Add: UIButton!
    @IBOutlet weak var Btn_Cancel: UIButton!
    @IBOutlet weak var txt_Password: SkyFloatingLabelTextField!
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//        
//        txt_Email.title = "Email"
//        txt_Email.placeholder = "Email"
//        txt_Password.placeholder = "Password"
//        txt_Password.title = "Password"
//    }
    
    class func instanceFromNib() -> AddCarPopUpViewController {
        
        return UINib(nibName: "AddCarPopUpViewController", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! AddCarPopUpViewController
    }
  

}
