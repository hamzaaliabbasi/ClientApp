//
//  SWFrontViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 29/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController

class SWFrontViewController: UIViewController {
    
    //MARK: Gloabl Variables
    
    var popUpView = AddCarPopUpViewController.instanceFromNib()
    
    //MARK: - Outlets
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    
    @IBOutlet weak var Btn_AddCar: UIButton!
    
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if self.revealViewController() != nil {
            
            MenuButton.target = self.revealViewController()
            MenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            
            self.navigationItem.title = "Home"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            self.Btn_AddCar.cornerRadius = 0.5 * Btn_AddCar.frame.width
        //  view.bringSubviewToFront(Btn_AddCar)
            
        }
    }
    
    //MARK: - Actions
    
    @IBAction func AddCar(_ sender: Any) {
        showPopUp()
      //  self.popUpView.dismissView.addTarget(self, action: #selector(self.dismissDialogue(_:)), for: .touchUpInside)
    }
    
    //MARK: - Functions
    
    func showPopUp()
    {
        self.popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
            popUpView.txt_Email.title = "Email"
             popUpView.txt_Email.placeholder = "Email"
               popUpView.txt_Password.placeholder = "Password"
                popUpView.txt_Password.title = "Password"
        self.popUpView.Btn_Cancel.addTarget(self, action: #selector(self.dismissDialogue(_:)), for: .touchUpInside)
        self.popUpView.Btn_Add.addTarget(self, action: #selector(self.Add_Car(_:)), for: .touchUpInside)
        self.view.addSubview(self.popUpView)
        
        
    }
    @objc func dismissDialogue(_ sender: UIButton)
    {
        self.popUpView.removeFromSuperview()
    }
    
    @objc func Add_Car(_ sender: UIButton)
    {
        // Add Car Code
    }
    

}
