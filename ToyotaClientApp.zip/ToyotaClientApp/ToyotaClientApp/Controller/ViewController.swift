//
//  ViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 29/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import GoogleSignIn
import Alamofire
class ViewController: UIViewController,GIDSignInUIDelegate{

   
    @IBOutlet weak var signInButton: GIDSignInButton!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func signIn(_ sender: Any) {
     self.performSegue(withIdentifier: "SWRevealViewController", sender: self)
    }
    
}

