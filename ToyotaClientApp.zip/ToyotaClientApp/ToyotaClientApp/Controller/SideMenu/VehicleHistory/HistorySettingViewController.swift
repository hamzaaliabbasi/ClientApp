//
//  HistorySettingViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 26/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class HistorySettingViewController: UIViewController {
    //MARK: - Global Variables
     static var cur: Int?
    //MARK: - Outlets
    @IBOutlet weak var firstView:UIView?
    @IBOutlet weak var secondView:UIView?
    
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //MARK: Actions
   
    @IBAction func segment(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            firstView?.alpha =  0
            secondView?.alpha = 1
            HistorySettingViewController.cur = 0
           // DateUpdate.update.currentPatten = 0
        case 1:
            firstView?.alpha =  1
            secondView?.alpha = 0
            HistorySettingViewController.cur = 1
        //    DateUpdate.update.currentPatten = 1
        default:
            
            firstView?.alpha =  0
            secondView?.alpha = 1
        }
    }
    
    @IBAction func btn_Save(_ sender: Any) {
        DateUpdate.update.currentPatten = HistorySettingViewController.cur
    self.navigationController?.popViewController(animated: true)
    }
    
    
}
