//
//  VehicleHistoryController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 10/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController

class VehicleHistoryController: UIViewController {
    //MARK: - Outlets
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
       
        
        if self.revealViewController() != nil {
            
            MenuButton.target = self.revealViewController()
            MenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            
           
                self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
                self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            
            
            
            
        }
        
    }
    
//MARK: - Actions

    @IBAction func btn_SeeHistory(_ sender: Any) {
        let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: "SeeHistoryViewController") as! SeeHistoryViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
