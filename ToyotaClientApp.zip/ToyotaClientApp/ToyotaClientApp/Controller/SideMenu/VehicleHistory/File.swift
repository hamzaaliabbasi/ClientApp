//
//  File.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 28/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
class DateUpdate{
    static let update = DateUpdate()
    
    let week = ["22 Jun - 28 Jun","24 Jun - 28 Jun","17 Jun - 23 Jun"]
    let Day = ["Fri,28 Jun","Thu,27 Jun"]
    let pattern = [week,Day]
    var currentPatten : Int?
    var cur_day : Int?
    var cur_week : Int?
    
    init(cur_pat:Int = 0, day: Int = 0, cur_Week:Int = 0) {
        self.currentPatten = cur_pat
        self.cur_day = day
        self.cur_week = cur_Week
    }
    
}
