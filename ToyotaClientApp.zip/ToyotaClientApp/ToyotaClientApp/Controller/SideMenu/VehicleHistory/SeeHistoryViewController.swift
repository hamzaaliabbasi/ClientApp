//
//  SeeHistoryViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 26/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class SeeHistoryViewController: UIViewController {
    //MARK: - Global Variables
    
    //MARK: - Outlets
    
    @IBOutlet weak var Btn_Date: UIButton!
    @IBOutlet weak var lab_DateTime: UILabel!
    @IBOutlet weak var Btn_Right: UIButton!
    @IBOutlet weak var Btn_left: UIButton!
    @IBOutlet weak var lab_calendar: NSLayoutConstraint!
    @IBOutlet weak var lab_DistanceTop: UILabel!
    @IBOutlet weak var lab_DistanceDown: UILabel!
    @IBOutlet weak var lab_lastSeen: UILabel!
    
    //MARK: - View LifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if(DateUpdate.update.currentPatten == 0){
            Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_day!], for: .normal)
            
        }
        else{
            Btn_Date.setTitle(DateUpdate.update.Day![DateUpdate.update.cur_week!], for: .normal)
            
            
        }
        
        
        print(DateUpdate.update.currentPatten)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        if(DateUpdate.update.currentPatten == 0){
            Btn_Date.setTitle(DateUpdate.update.Day![DateUpdate.update.cur_day!], for: .normal)
            
        }
        else{
            Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_week!], for: .normal)
            
            
        }
      
    }
    
    //MARK: - Actions

    @IBAction func ChangeDate(_ sender: Any) {
        let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: "HistorySettingViewController")as! HistorySettingViewController
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func forward(_ sender: Any) {
        if(DateUpdate.update.currentPatten == 1){
            if( DateUpdate.update.cur_week! < 2){
                DateUpdate.update.cur_week =  DateUpdate.update.cur_week! + 1
            }
            Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_week!], for: .normal)
            print(DateUpdate.update.cur_week!)
                }
        else{
            if(DateUpdate.update.cur_day! < 1  ){
                DateUpdate.update.cur_day =  DateUpdate.update.cur_day! + 1
            }
        
            Btn_Date.setTitle(DateUpdate.update.Day![DateUpdate.update.cur_day!], for: .normal)
            print(DateUpdate.update.cur_day!)
        }
    }
    
    @IBAction func backward(_ sender: Any) {
    if(DateUpdate.update.currentPatten == 1){
        if( DateUpdate.update.cur_week! > 0){
            DateUpdate.update.cur_week =  DateUpdate.update.cur_week! - 1
    }
        
        Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_week ?? 0]
, for: .normal)
     
    }
    else{
        if( DateUpdate.update.cur_day! > 0){
            DateUpdate.update.cur_day =  DateUpdate.update.cur_day! - 1
    }
        Btn_Date.setTitle( DateUpdate.update.Day![DateUpdate.update.cur_day!], for: .normal)
        
    print(DateUpdate.update.cur_day!)
        }
    }
}
