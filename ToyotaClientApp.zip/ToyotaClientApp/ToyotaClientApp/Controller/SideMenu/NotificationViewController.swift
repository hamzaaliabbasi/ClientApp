//
//  NotificationViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 10/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController
class NotificationViewController: UIViewController {
    
    //MARK: - Global Variables
    
    var details = ["Your car with reg # AWQ242 is violated with a speed of 60.000 km/h at 0.095 KM of Custom House,Karachi","Your car with reg # AWQ242 is violated with a speed of 60.000 km/h at 0.095 KM of Khadda Market,Karachi"]
    var date = ["6/26/2019","6/26/2019"]
    var time = ["10:08:07 AM","10:08:07 AM"]
    
    
    //MARK: - Outlets
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    
    @IBOutlet weak var table: UITableView!
    
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
   self.table.tableFooterView = UIView()
        table.rowHeight = UITableView.automaticDimension
        table.estimatedRowHeight = 600

        
        if self.revealViewController() != nil {
            
            MenuButton.target = self.revealViewController()
            MenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            
            
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            
            
            
            
        }
    }
    

}
extension NotificationViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return details.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationTableViewCell") as! NotificationTableViewCell
        cell.lab_details.text = self.details[indexPath.row]
        cell.lab_date.text = self.date[indexPath.row]
        cell.lab_time.text = self.time[indexPath.row]
        cell.lab_tc.text = "TC"
        cell.img_logo.image = UIImage(named: "nav_speed")
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableView.automaticDimension    }
}
