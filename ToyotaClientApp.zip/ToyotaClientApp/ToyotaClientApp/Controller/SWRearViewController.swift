//
//  SWRearViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 29/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController


class SWRearViewController: UIViewController {
    
    
    var menu = ["Home","Vehicle History","Alerts","Notification","Profile","Logout"]
    var contollers  = ["SWFrontViewController","VehicleNavigationController","AlertNavigationController","NotificationViewController","ProfileViewController","ViewController"]
    var icons = ["nav_home","nav_stats","nav_alerts","nav_notification","nav_profile","nav_logout"]
    
    var arryOfControllers: [UIViewController] = [VehicleHistoryController(),AlertsViewController(),NotificationViewController(),ProfileViewController()]
    
    //MARK: - Outlets
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var EmailLabel: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    
    //MARK: - viewDidLoad

    override func viewDidLoad() {
        super.viewDidLoad()
      
    
       
        // Do any additional setup after loading the view.
        table.tableFooterView = UIView()
        
        setProfile(name: "Hamza", email: "hamzaabbasi678@gmail.com", image: UIImage(named: "G")!)
        
        profilePic.layer.borderWidth = 0.7
        profilePic.layer.masksToBounds = false
        profilePic.layer.borderColor = UIColor.black.cgColor
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
    }
    
    func setProfile(name: String , email: String , image : UIImage){
        NameLabel.text = name
        EmailLabel.text = email
        profilePic.image = image
    }
  

}
extension SWRearViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "SWTableViewCell") as! SWTableViewCell
        cell.LogoImage.image = UIImage(named: icons[indexPath.row])
        cell.LogoLabel.text = menu[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
         var reveal : SWRevealViewController = self.revealViewController()
        
        
        switch indexPath.row {
        case 0:
            
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
//            vc.navigationController?.navigationBar.isHidden = false
//                 reveal.setFrontViewPosition(FrontViewPosition.left, animated: false)
            reveal.pushFrontViewController(vc, animated: true)
                  self.revealViewController()?.revealToggle(animated: true)
           // reveal.setFront(vc, animated: true)
            
        case 1:
            let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: self.contollers[indexPath.row]) as! UINavigationController
            reveal.pushFrontViewController(vc, animated: false)
            self.revealViewController()?.revealToggle(animated: true)
      
        case 2:
            let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: self.contollers[indexPath.row]) as! UINavigationController
           reveal.pushFrontViewController(vc, animated: false)
            self.revealViewController()?.revealToggle(animated: true)
        case 3:
            let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: self.contollers[indexPath.row]) as! NotificationViewController
             reveal.pushFrontViewController(vc, animated: false)
            self.revealViewController()?.revealToggle(animated: true)
        case 4:
            let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: self.contollers[indexPath.row]) as! ProfileViewController
             reveal.pushFrontViewController(vc, animated: false)
            self.revealViewController()?.revealToggle(animated: true)
        case 5:
            self.revealViewController()?.revealToggle(animated: true)
            let Alert = UIAlertController(title: "Logout", message: "Are you sure that you want to logout?", preferredStyle: .alert)
            
            
            let alert_Action = UIAlertAction(title: "Confirm", style: .default, handler: {(alert: UIAlertAction!) in
               self.dismiss(animated: false, completion: nil)})
            Alert.addAction(alert_Action)
            Alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            self.present(Alert, animated: true, completion: nil)
            
            
        default:
            self.revealViewController()?.revealToggle(animated: true)
        
        
    }
    
    }
    
    
    
    
}
