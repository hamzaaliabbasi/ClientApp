//
//  Network.swift
//  ToyotaClientApp
//
//  Created by Saad Muhammad Khan on 12/07/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation

class Network : NSObject{
    static let sharedInstance =  Network()
    let baseUrl = "http://103.9.23.45/TrakkerMobileAppServiceStagging/Service1.svc/" 
    
}
