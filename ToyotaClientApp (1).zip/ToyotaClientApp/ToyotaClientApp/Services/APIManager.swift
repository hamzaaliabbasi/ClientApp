

import Foundation
import UIKit

typealias DefaultAPIFailureClosure = (NSError) -> Void
typealias DefaultAPISuccessClosure = (Dictionary<String,AnyObject>) -> Void
typealias DefaultBoolResultAPISuccesClosure = (Bool) -> Void
typealias DefaultArrayResultAPISuccessClosure = (Array<AnyObject>) -> Void
typealias DefaultImageResultClosure = (UIImage) -> Void
typealias DefaultAnyResultClosure = (Any) -> Void
// download closures
typealias DefaultDownloadSuccessClosure = (Data) -> Void
typealias DefaultDownloadProgressClosure = (Double, Int) -> Void
typealias DefaultDownloadFailureClosure = (NSError, Data, Bool) -> Void


protocol APIErrorHandler {
    func handleErrorFromResponse(response: Dictionary<String,AnyObject>)
    func handleErrorFromERror(error:NSError)
}


class APIManager: NSObject {
    
    
    static let sharedInstance = APIManager()
    
//    var serverToken: String? {
//        get{
//            return ""
//        }
//    }
    
//    var accessToken: String? {
//        get {
//            return AppStateManager.sharedInstance.loggedInUser?.access_token
//        }
//    }
    
    let usersAPIManager = UsersAPIManager()
//    let claimAPIManager = ClaimAPIManager()
//    let fundsAPIManager = FundsAPIManager()
//    let lifePolicyAPIManager = LifePolicyAPIManager()
//    let webdocAPIManager = WebDocAPIManager()
//    let tripInsuranceManager = TripInsuranceAPIManager()
    
}
