

import Foundation
import Alamofire
import SwiftyJSON

class UsersAPIManager:APIManagerBase{
    
    let updateProfile = "http://103.9.23.45/TrakkerMobileAppServiceStagging/Service1.svc/InsertSocialNetworkData"
    
    //MARK: - /Login
    func postWithJsonForCreateandInsert(url:String ,with data: Data , success: @escaping (NSDictionary) -> Void, failure: @escaping DefaultAPIFailureClosure) {
       // let route: URL = POSTURLforLogin(route: Route.insertSocialNetworkData.rawValue)!
//        DispatchQueue.main.async {
            self.InsertSocialLogin(url: url, with: data, success: success, failure: failure)
//        }
        }
        
    
    // MARK: - /Registration
//    func registration(params: Parameters, success: @escaping DefaultAnyResultClosure, failure: @escaping DefaultAPIFailureClosure) {
//        let route: URL = POSTURLforRoute(route: Route.Registration.rawValue)!
//        //  self.postRequestWith(route: route, parameters: params, success: success, failure: failure, withHeaders: true)
//        print(route)
//        self.postRequestForAnyWith(route: route, parameters: params, success: success, failure: failure, withHeaders: true)
//    }
//
//
//    // MARK: - /ChangePassword
//    func changePassword(params: Parameters, success: @escaping DefaultAPISuccessClosure, failure: @escaping DefaultAPIFailureClosure) {
//        let route: URL = POSTURLforRoute(route: Route.ChangePassword.rawValue)!
//        self.postRequestWith(route: route, parameters: params, success: success, failure: failure, withHeaders: true)
//    }
//
//    // MARK: - /ContactUsLogoutService
//    func SendMessageLoggedOut(params: Parameters, success: @escaping DefaultAPISuccessClosure, failure: @escaping DefaultAPIFailureClosure) {
//        let route: URL = POSTURLforRoute(route: Route.ContactUsLoggedOut.rawValue)!
//        self.postRequestWith(route: route, parameters: params, success: success, failure: failure, withHeaders: true)
//    }
//
//    // MARK: - /ContactUsLogoutService
//    func getForgotPasswordData(params: Parameters, success: @escaping DefaultAnyResultClosure, failure: @escaping DefaultAPIFailureClosure) {
//        let route: URL = POSTURLforRoute(route: Route.ForgotPassword.rawValue)!
//        self.postRequestForAnyWith(route: route, parameters: params, success: success, failure: failure, withHeaders: true)
//    }
//
//    func resetPassword(params: Parameters, success: @escaping DefaultAnyResultClosure, failure: @escaping DefaultAPIFailureClosure) {
//        let route: URL = POSTURLforRoute(route: Route.resetPassword.rawValue)!
//        self.postRequestForAnyWith(route: route, parameters: params, success: success, failure: failure, withHeaders: true)
//    }
    
    // Mark: - /GetHospitalList
//    func getHospitalDetailsList(params: Parameters, success: @escaping DefaultArrayResultAPISuccessClosure, failure: @escaping DefaultAPIFailureClosure) {
//        let route: URL = URL(string: "http://portal.tpllife.com:9040/api/Package/GetHospital")!
//        self.getRequestWith(route: route, parameters: params, success: success, failure: failure, withHeader: true)
//    }
//    
    func saveProfile(url: String,jsonData: Data , header:[String:String], parameters: [String: Any], callback: ((JSON?, Error?) -> Void)?) {
        print("API - Request URL: \(url)")
        let route = URL(string: url)
        var request = URLRequest(url: route!)
        request.httpMethod = HTTPMethod.post.rawValue
        request.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        request.allHTTPHeaderFields = header
        //
        Alamofire.request(request).responseJSON { (response:DataResponse<Any>) in
            
            switch(response.result) {
            case .success(_):
                if response.result.isSuccess {
                    if let value: Any = response.result.value as AnyObject? {
                        let response = JSON(value)
                        callback?(response, nil)
                    }
                }
                else {
                    print("Request failed with error: \(response.result.error!.localizedDescription)")
                    callback?(nil, response.result.error!)
                }
            case .failure(_):
                print("Request failed with error: \(response.result.error!.localizedDescription)")
                callback?(nil, response.result.error!)
                break
            }
        }
    }
    
    func updateProfile(params: Parameters, success: @escaping DefaultAPISuccessClosure, failure: @escaping DefaultAPIFailureClosure) {
        let route = URL(string: self.updateProfile)
        self.postRequestWith(route: route!, parameters: params, success: success, failure: failure, withHeaders: true)
    }
    
}
