/*
 Copyright (c) 2018 Swift Models Generated from JSON powered by http://www.json4swift.com
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import Foundation
//import RMMapper
/* For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar */

public class User: NSObject, NSCoding {
    public var email : String?
    public var Gender: String?
    public var userName : String?
    public var cellNumber : String?
    public var status: String?
    public var picURL: String?
    public var socialID : String?
    public var trackID : String?
    public var msg : String?
    public var error : String?
    public var error_description : String?


    

    
    /**
     Returns an array of models based on given dictionary.
     
     Sample usage:
     let json4Swift_Base_list = Json4Swift_Base.modelsFromDictionaryArray(someDictionaryArrayFromJSON)
     
     - parameter array:  NSArray from JSON dictionary.
     
     - returns: Array of Json4Swift_Base Instances.
     */
    public class func modelsFromDictionaryArray(array:NSArray) -> [User]
    {
        var models:[User] = []
        for item in array
        {
            models.append(User(dictionary: item as! NSDictionary)!)
        }
        return models
    }
    
    /**
     Constructs the object based on the given dictionary.
     
     
     
     {
     "CellNumber": "+923412123354",
     "Email": "hammad.khan4735@gmail.com",
     "Gender": "Male",
     "Msg": "Welcome Back,profile updated successfully",
     "Name": "Hammad Khan",
     "PicUrl": "https://mytrakker.tpltrakker.com/TplTrakkerAndTrackMeMobileAppService/UserProfile/User_Profile_Pic_876568.jpg",
     "Social_ID": null,
     "Status": "1",
     "TrackID": "TPL-00000007"
     }
     
     Sample usage:
     let json4Swift_Base = Json4Swift_Base(someDictionaryFromJSON)
     
     - parameter dictionary:  NSDictionary from JSON.
     
     - returns: Json4Swift_Base Instance.
     */
    required public init?(dictionary: NSDictionary) {
        super.init()
        email = dictionary["Email"] as? String
        Gender = dictionary["Gender"] as? String
        userName = dictionary["Name"] as? String
        picURL = dictionary["PicUrl"] as? String
        msg = dictionary["Msg"] as? String
        cellNumber = dictionary["CellNumber"] as? String
        socialID = dictionary["Social_ID"] as? String
        status = dictionary[".Status"] as? String
        trackID = dictionary[".TrackID"] as? String
        error = dictionary[".error"] as? String ?? ""
    
        error_description = dictionary[".error_description"] as? String ?? ""
        

    }
    
    
    /**
     Returns the dictionary representation for the current instance.
     
     - returns: NSDictionary.
     */
    public func dictionaryRepresentation() -> NSDictionary {
        
        let dictionary = NSMutableDictionary()
        
        dictionary.setValue(self.email, forKey: "Email")
        dictionary.setValue(self.Gender, forKey: "Gender")
        dictionary.setValue(self.userName, forKey: "Name")
        dictionary.setValue(self.picURL, forKey: "PicUrl")
        dictionary.setValue(self.msg, forKey: "Msg")
        dictionary.setValue(self.cellNumber, forKey: "CellNumber")
        dictionary.setValue(self.socialID, forKey: "Social_ID")
        dictionary.setValue(self.status, forKey: "Status")
        dictionary.setValue(self.trackID, forKey: "TrackID")
        dictionary.setValue(self.error, forKey: "error")
        dictionary.setValue(self.error_description, forKey: "error_description")
        
        return dictionary
    }
    
    public func encode(with encoder: NSCoder) {
        //Encode properties, other class variables, etc
        encoder.encode(self.email, forKey: "Email")
        encoder.encode(self.Gender, forKey: "Gender")
        encoder.encode(self.userName, forKey: "Name")
        
        encoder.encode(self.picURL, forKey: "PicUrl")
        encoder.encode(self.msg, forKey: "Msg")
        encoder.encode(self.cellNumber, forKey: "CellNumber")
        
        encoder.encode(self.socialID, forKey: "Social_ID")
        encoder.encode(self.status, forKey: "Status")
        encoder.encode(self.trackID, forKey: "TrackID")
        
        encoder.encode(self.error, forKey: "error")
        encoder.encode(self.error_description, forKey: "error_description")

    }
    
    required public init?(coder decoder: NSCoder) {
        //decode properties, other class vars
        super.init()
        self.email = decoder.decodeObject(forKey: "Email") as? String
        self.Gender = decoder.decodeObject(forKey: "Gender") as? String
        self.userName = decoder.decodeObject(forKey: "Name") as? String
        
        self.picURL = decoder.decodeObject(forKey: "PicUrl") as? String
        self.msg = decoder.decodeObject(forKey: "Msg") as? String
        self.cellNumber = decoder.decodeObject(forKey: "CellNumber") as? String
        
        self.socialID = decoder.decodeObject(forKey: "Social_ID") as? String
        self.status = decoder.decodeObject(forKey: "Status") as? String
        self.trackID = decoder.decodeObject(forKey: "TrackID") as? String
        

        self.error = decoder.decodeObject(forKey: "error") as? String
        self.error_description = decoder.decodeObject(forKey: "error_description") as? String

        
    }
    
}

