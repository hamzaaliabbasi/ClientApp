//
//  AppStateManager.swift
//  tpllifev1
//
//  Created by Tahir Raza on 22/06/2018.
//  Copyright © 2018 TPL Life. All rights reserved.
//

import UIKit

//class AppStateManager: NSObject {
    
//    static let sharedInstance = AppStateManager()
//    var loggedInUser: User?
////    var loggedInWebDocUser: WebDocUser?
////    var loggedInFMDUser: FMDUser?
////    var loggedInTripInsuranceUser: TripInsuranceUser?
//    
//    override init() {
//        super.init()
//        if Constants.USER_DEFAULTS.object(forKey: UserDefaultsKeys.User) != nil {
//            if let userModel = Constants.USER_DEFAULTS.object(forKey: UserDefaultsKeys.User) as? User {
//                loggedInUser = userModel
//            }
//        }
////
////        if Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.FMDUser) != nil {
////            if let userModel = Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.FMDUser) as? FMDUser {
////                loggedInFMDUser = userModel
////            }
////        }
////
////        if Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.tripInsuranceUser) != nil {
////            if let userModel = Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.tripInsuranceUser) as? TripInsuranceUser {
////                loggedInTripInsuranceUser = userModel
////            }
////        }
////
////
////
////        if Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.WebDocUser) != nil {
////            if let webDocUserModel = Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.WebDocUser) as? WebDocUser {
////                loggedInWebDocUser = webDocUserModel
////            }
////        }
//    }
////
////    func isUserLoggedIn() -> Bool{
////
////        if (self.loggedInUser) != nil {
////            return true
////        }
////        return false
////    }
////
////    func isWebDocUserLoggedIn() -> Bool {
////        if (self.loggedInWebDocUser) != nil {
////            return true
////        }
////        return false
////    }
//    
//    func createUser(with userModel: User) {
//        Constants.USER_DEFAULTS.rm_setCustomObject(userModel, forKey: UserDefaultsKeys.User)
//        print("login obj \(Constants.USER_DEFAULTS.rm_customObject(forKey: UserDefaultsKeys.User))")
//        //commented by saad
//        // def keys for older version
//        Constants.USER_DEFAULTS.set(userModel.access_token, forKey: UserDefaultsKeys.accessToken)
//        Constants.USER_DEFAULTS.set(userModel.cnic, forKey: UserDefaultsKeys.CnicNumber)
//        Constants.USER_DEFAULTS.set(userModel.userName, forKey: UserDefaultsKeys.Email)
//        Constants.USER_DEFAULTS.set(userModel.firstName, forKey: UserDefaultsKeys.firstName)
//        Constants.USER_DEFAULTS.set(userModel.lastName, forKey: UserDefaultsKeys.lastName)
//        Constants.USER_DEFAULTS.set(userModel.phoneNumber, forKey: UserDefaultsKeys.PhoneNumber)
//        Constants.USER_DEFAULTS.set(userModel.access_token, forKey: UserDefaultsKeys.accessToken)
//    
//        
//        self.loggedInUser = userModel
//    }
//    
//    func createWebDocUser(with webDocUser: WebDocUser) {
//        Constants.USER_DEFAULTS.rm_setCustomObject(webDocUser, forKey: UserDefaultsKeys.WebDocUser)
//        self.loggedInWebDocUser = webDocUser
//    }
//    
//    func createFMDUser(with fmdUser: FMDUser) {
//        Constants.USER_DEFAULTS.rm_setCustomObject(fmdUser, forKey: UserDefaultsKeys.FMDUser)
//        self.loggedInFMDUser = fmdUser
//    }
//    
//    
//    func createTripInsuranceUser(with tripInsuranceUser: TripInsuranceUser) {
//        Constants.USER_DEFAULTS.rm_setCustomObject(tripInsuranceUser, forKey: UserDefaultsKeys.tripInsuranceUser)
//        self.loggedInTripInsuranceUser = tripInsuranceUser
//    }
//
//    
//    func logoutUser() {
//        
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.User)
//        
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.accessToken)
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.CnicNumber)
//        
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.Email)
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.firstName)
//        
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.lastName)
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.PhoneNumber)
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.isTripInsuranceUserRegistered)
//        
//        self.loggedInUser = nil
//        
//        self.logoutWebDocUser()
//        self.logoutTripinsuranceUser()
//    }
//    
//    func logoutWebDocUser() {
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.WebDocUser)
//        self.loggedInWebDocUser = nil
//    }
//    
//    func logoutTripinsuranceUser() {
//        Constants.USER_DEFAULTS.removeObject(forKey: UserDefaultsKeys.tripInsuranceUser)
//        self.loggedInTripInsuranceUser = nil
//    }
//
//}
