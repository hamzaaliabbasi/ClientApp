//
//  singleton.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 03/07/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
import GoogleSignIn
class currentUser {
     var cur_user : User?
    
    static let sharedUser = currentUser()
}
