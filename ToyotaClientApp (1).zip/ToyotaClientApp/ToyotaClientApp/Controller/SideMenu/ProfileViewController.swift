//
//  ProfileViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 10/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController
class ProfileViewController: UIViewController {
    
    //MARK: - Outlets
    
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_number: UITextField!
    @IBOutlet weak var txt_gender: UITextField!
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var Btn_Edit: UIButton!
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    
    //MARK: - ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        if self.revealViewController() != nil {
            
            MenuButton.target = self.revealViewController()
            MenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            
            
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            
            
            txt_name.placeholder = currentUser.sharedUser.cur_user?.userName
            txt_email.placeholder = currentUser.sharedUser.cur_user?.email
            txt_number.placeholder = currentUser.sharedUser.cur_user?.email
            
            
        }
        
        self.Btn_Edit.clipsToBounds = true
        self.Btn_Edit.cornerRadius = 0.5 * Btn_Edit.bounds.size.width
    }//ViewDidLoad Ends
    

    //MARK: - Actions
    
    @IBAction func Edit_btn(_ sender: Any) {
        txt_name.isEnabled = true
        txt_email.isEnabled = true
        txt_gender.isEnabled = true
        txt_number.isEnabled = true
        
        txt_name.text = txt_name.placeholder
        txt_email.text = txt_email.placeholder
        txt_gender.text = txt_gender.placeholder
        txt_number.text = txt_number.placeholder
        
        txt_name.becomeFirstResponder()
        
    }
    
    
    @IBAction func Update_btn(_ sender: Any) {
    }
}
