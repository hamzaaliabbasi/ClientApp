//
//  CarSettingViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 20/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class CarSettingViewController: UIViewController {
    
    //MARK: - GlobalVariables
    lazy var alerts = ["Speed Alerts","Hand Break","Ignition On","Front Left Door Opened","Front Left Door Closed","Front Right Door Opened","Front Right Door Closed","Rear Left Door Opened","Rear Left Door Closed","Rear Right Door Opened","Rear Right Door Closed","Trunk Open","Trunk Closed","Harsh Breaking","Ignition Off","Low Fuel Alert"]
    var Switches: Array<UISwitch> = []
    
    //MARK: - Outlets
    
    @IBOutlet weak var table: UITableView!
    
    
    //MARK: - ViewDidLoad
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        table.tableFooterView = UIView()
        
        for _ in self.alerts{
            Switches.append(UISwitch())
        }
    }
    

   
    @IBAction func btn_Back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

//MARK: - Extension
extension CarSettingViewController:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alerts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CarSettingTableViewCell") as! CarSettingTableViewCell
        cell.Alert_label?.text = self.alerts[indexPath.row]
        cell.Alert_Switch = self.Switches[indexPath.row]
        return cell
    }
    
  
    
    
}
