//
//  AlertsViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 10/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController

class AlertsViewController: UIViewController {
    
    //MARK: - Global Variables
    var members: [String]  = ["Taha"]

    //MARK: - Outlets
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    
    //MARK: - ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.table.tableFooterView = UIView()
        
   //For SWReveal
        if self.revealViewController() != nil {
            
            MenuButton.target = self.revealViewController()
            MenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            }
        
    }//View Did Load Ends
    


}

//MARK: - Extension
extension AlertsViewController:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return members.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SWTableViewCell") as! SWTableViewCell
        cell.LogoLabel.text = self.members[indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: "CarSettingViewController") as! CarSettingViewController
 //       present(vc, animated: false, completion: nil)
       self.navigationController?.pushViewController(vc, animated: false)
    }
    
    
}



