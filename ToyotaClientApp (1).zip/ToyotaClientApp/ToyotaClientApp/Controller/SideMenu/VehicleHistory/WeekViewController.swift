//
//  WeekViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 28/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import BEMCheckBox
class WeekViewController: UIViewController {
    
    //MARK: - Outlets
    @IBOutlet weak var first_Chk: BEMCheckBox!
    @IBOutlet weak var second_Chk: BEMCheckBox!
     @IBOutlet weak var third_Chk: BEMCheckBox!
    //MARK: - View Did Load
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
       update_Checks()
    }
    override func viewWillAppear(_ animated: Bool) {
     update_Checks()
    }
    //MARK: - Actions

    @IBAction func chkbox_First(_ sender: Any) {
        DateUpdate.update.cur_week = 0
        first_Chk.on = true
        second_Chk.on = false
        third_Chk.on = false
    }
    
    @IBAction func chkbox_Second(_ sender: Any) {
        first_Chk.on = false
        second_Chk.on = true
        third_Chk.on = false
        DateUpdate.update.cur_week = 1
    }
    
    @IBAction func chkbox_Third(_ sender: Any) {
        DateUpdate.update.cur_week = 2
        first_Chk.on = false
        second_Chk.on = false
        third_Chk.on = true
    }
    
    //MARK: - Functions
    func update_Checks(){
        if( DateUpdate.update.cur_week == 0)
        {
            first_Chk.on = true
            second_Chk.on = false
            third_Chk.on = false
        }
        else if(DateUpdate.update.cur_week == 1)
        {
            first_Chk.on = false
            second_Chk.on = true
            third_Chk.on = false
        }
        else if(DateUpdate.update.cur_week == 2)
        {
            first_Chk.on = false
            second_Chk.on = false
            third_Chk.on = true
        }
        HistorySettingViewController.cur = 1
    }
    
}
