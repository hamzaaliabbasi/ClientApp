//
//  SeeHistoryViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 26/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import GoogleMaps

class SeeHistoryViewController: UIViewController {
    
    //MARK: - Global Variables
    
    var locationManager = CLLocationManager()
    var camera:GMSCameraPosition?
    var maker1 = GMSMarker()
    
    //MARK: - Outlets
       @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var Btn_Date: UIButton!
    @IBOutlet weak var lab_DateTime: UILabel!
    @IBOutlet weak var Btn_Right: UIButton!
    @IBOutlet weak var Btn_left: UIButton!
    @IBOutlet weak var lab_calendar: NSLayoutConstraint!
    @IBOutlet weak var lab_DistanceTop: UILabel!
    @IBOutlet weak var lab_DistanceDown: UILabel!
    @IBOutlet weak var lab_lastSeen: UILabel!
    
    //MARK: - View LifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if(DateUpdate.update.currentPatten == 0){
            Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_day!], for: .normal)
            
        }
        else{
            Btn_Date.setTitle(DateUpdate.update.Day![DateUpdate.update.cur_week!], for: .normal)
            
            
        }
        
        //location
        self.mapView.delegate = self
        
        locationManager.delegate = self
        
        locationManager.requestAlwaysAuthorization()
        
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        
        print(DateUpdate.update.currentPatten)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.locationManager.startUpdatingLocation()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(DateUpdate.update.currentPatten == 0){
            Btn_Date.setTitle(DateUpdate.update.Day![DateUpdate.update.cur_day!], for: .normal)
            
        }
        else{
            Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_week!], for: .normal)
            
            
        }
      
    }
    
    //MARK: - Actions

    @IBAction func ChangeDate(_ sender: Any) {
        let vc = UIStoryboard.init(name: "SideMenu", bundle: nil).instantiateViewController(withIdentifier: "HistorySettingViewController")as! HistorySettingViewController
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func forward(_ sender: Any) {
        if(DateUpdate.update.currentPatten == 1){
            if( DateUpdate.update.cur_week! < 2){
                DateUpdate.update.cur_week =  DateUpdate.update.cur_week! + 1
            }
            Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_week!], for: .normal)
            print(DateUpdate.update.cur_week!)
                }
        else{
            if(DateUpdate.update.cur_day! < 1  ){
                DateUpdate.update.cur_day =  DateUpdate.update.cur_day! + 1
            }
        
            Btn_Date.setTitle(DateUpdate.update.Day![DateUpdate.update.cur_day!], for: .normal)
            print(DateUpdate.update.cur_day!)
        }
    }
    
    @IBAction func backward(_ sender: Any) {
    if(DateUpdate.update.currentPatten == 1){
        if( DateUpdate.update.cur_week! > 0){
            DateUpdate.update.cur_week =  DateUpdate.update.cur_week! - 1
    }
        
        Btn_Date.setTitle(DateUpdate.update.week![DateUpdate.update.cur_week ?? 0]
, for: .normal)
     
    }
    else{
        if( DateUpdate.update.cur_day! > 0){
            DateUpdate.update.cur_day =  DateUpdate.update.cur_day! - 1
    }
        Btn_Date.setTitle( DateUpdate.update.Day![DateUpdate.update.cur_day!], for: .normal)
        
    print(DateUpdate.update.cur_day!)
        }
    }
    //MARK: - Functions
    func showCurrentLocation(){
        
        camera = GMSCameraPosition.camera(withLatitude: (self.locationManager.location?.coordinate.latitude)!, longitude: (self.locationManager.location?.coordinate.longitude)!, zoom: 15)
        mapView.camera = camera!
        
        mapView.settings.myLocationButton = true
        // mapView.isMyLocationEnabled = true
        
        
        
    }
}

extension SeeHistoryViewController: GMSMapViewDelegate,CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locationManager.location?.coordinate)
        
        //  maker1.icon = GMSMarker.markerImage(with: UIColor.gray)
        //        maker1.icon?.images = UIImage(named: "nav_trip")
        maker1.icon = UIImage(named: "nav_trip")
        maker1.position = manager.location!.coordinate
        maker1.map = mapView
        showCurrentLocation()
        self.locationManager.stopUpdatingLocation()
        
    }
}

