//
//  DateViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 28/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import BEMCheckBox

class DateViewController: UIViewController {
    //MARK: - Gloabal Variables
    var current_day: Int?
    
    //MARK: - Outlets
    
    @IBOutlet weak var first_Chk: BEMCheckBox!
    @IBOutlet weak var second_Chk: BEMCheckBox!
    
    //MARK: - ViewLifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
     
      update_Checks() 
      
        
    }
    override func viewWillAppear(_ animated: Bool) {
        update_Checks()
    }
    //MARK: - Actions
    
    @IBAction func chkbox_First(_ sender: Any) {
            DateUpdate.update.cur_day = 0
        first_Chk.on = true
        second_Chk.on = false
    }
    
    @IBAction func chkbox_Second(_ sender: Any) {
        DateUpdate.update.cur_day = 1
        first_Chk.on = false
        second_Chk.on = true
    }
    
    //MARK:- Functions
    
    func update_Checks(){
        if( DateUpdate.update.cur_day == 0)
        {
            first_Chk.on = true
            second_Chk.on = false
        }
        else if(DateUpdate.update.cur_day == 1)
        {
            first_Chk.on = false
            second_Chk.on = true
        }
        HistorySettingViewController.cur = 0
    }
    
    
    
}
