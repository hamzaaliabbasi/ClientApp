//
//  ViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 29/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import Google
import GoogleSignIn
import SWRevealViewController
import Alamofire

class ViewController: UIViewController{
    //MARK: - Global Variables
    var ChangeScreen_StatusArray = [false,true]
    var ChangeScreen_Status:Int?
let signInButton = GIDSignInButton(frame: CGRect(x: 0, y: 0, width: 230, height: 48))
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        
        super.viewDidLoad()

        //For Google Sign In Button 

        var error:NSError?
        GGLContext.sharedInstance()?.configureWithError(&error)
       
        
        GIDSignIn.sharedInstance()?.uiDelegate = self
        GIDSignIn.sharedInstance()?.delegate = self
        GIDSignIn.sharedInstance()?.signInSilently()
        signInButton.center = view.center
        view.addSubview(signInButton)
        }//ViewDidLoad Ends
    
    //MARK: - Actions

    // MARK: - Functions
    
    func insertApiCall(email:String,name:String,picUrl:String,DeviceToken:String,Gender:String,CellNumber:String,TrackId:String,ID:String)
    {
        
        
        
        let url = Network.sharedInstance.baseUrl + "InsertSocialNetworkData"
        
        let socialType = "GOOGLE"
        let deviceType = "iOS"
        let json = "{\"Name\":\"\(name)\",\"PicUrl\":\"\(picUrl)\",\"EmailAddress\":\"\(email)\",\"SocialType\":\"\(socialType)\",\"Devicetoken\":\"\(DeviceToken)\",\"DeviceType\":\"\(deviceType)\",\"Gender\":\"\(Gender)\",\"CellNumber\":\"\(CellNumber)\",\"ID\":\"\(ID)\",\"TrackId\":\"\(TrackId)\"}"
        
                let jsonData = json.data(using: .utf8, allowLossyConversion: false)!
        
        APIManager.sharedInstance.usersAPIManager.postWithJsonForCreateandInsert(url: url, with: jsonData, success: { (successObj) in
            //    Utility.main.showActivityIndicatory(uiView: self.view)
            let userModel = User(dictionary: successObj as NSDictionary)
            currentUser.sharedUser.cur_user = userModel

            //setting user defaults
            UserDefaults.standard.set(userModel?.userName, forKey: "Name")
            UserDefaults.standard.setValue(userModel?.email, forKey: "Email")
            UserDefaults.standard.setValue(userModel?.Gender, forKey: "Gender")
            UserDefaults.standard.setValue(userModel?.cellNumber, forKey: "CellNumber")
            UserDefaults.standard.setValue(userModel?.msg, forKey: "Msg")
            
            let userName = UserDefaults.standard.string(forKey: "Name")!
            let social_id = GIDSignIn.sharedInstance()?.currentUser.userID!
            
             //           self.createGroupApiCall(Grp_name: userName, Grp_Pic: "", Group_Desc: "", socialID:user.userID!)
            if(userModel?.userName != nil){
                print("error nil nae hai error: \(userModel?.error)")
           //     AppStateManager.sharedInstance.createUser(with: userModel!)
               // Constants.APP_DELEGATE.changeRootToDashboard()
                
            }else if(userModel?.userName == nil){
                print("error nil hai error: \(userModel?.error)")
 
                Utility.main.showAlert(message: "Wrong Credentials", title: "Alert!")
            }else{
                print("connection me masla hai: \(userModel?.error)")
            
                 Utility.main.showAlert(message: "Plesae try again", title: "Alert!")
            }
        }) { (failure) in
           // Utility.main.hideLoader()
            Utility.main.showAlert(message: "Error occured or maybe your internet appears to be offline", title: "Alert!")
        }
        
    }//insert api function ends
    
    func createGroupApiCall(Grp_name: String, Grp_Pic: String, Group_Desc: String, socialID:String){
        let url = Network.sharedInstance.baseUrl + "CreateGroup?PackageID=116"
        
        let json = "{\"Group_Category\":\"\(Grp_name)\",\"Group_Pic\":\"\(Grp_Pic)\",\"Group_desc\":\"\(Group_Desc)\",\"SocialID\":\"\(socialID)\"}"
        
        let jsonData = json.data(using: .utf8, allowLossyConversion: false)!
        
        APIManager.sharedInstance.usersAPIManager.postWithJsonForCreateandInsert(url: url, with: jsonData, success: { (successObj) in
            //    Utility.main.showActivityIndicatory(uiView: self.view)
            
            self.ChangeScreen_Status = successObj["Status"] as! Int
            

        }) { (failure) in
            // Utility.main.hideLoader()
            Utility.main.showAlert(message: "Error occured or maybe your internet appears to be offline", title: "Alert!")
        }
        
        
        
    }
    
    
    
    
    
    
}//class ends

//MARK: _ Extension
extension ViewController:GIDSignInUIDelegate,GIDSignInDelegate
{
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func signIn(signIn: GIDSignIn!,
                dismissViewController viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
      
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if(error != nil)
        {
            print(error)
            
            
            return
        }
        else{
            // user.profile.imageURL(withDimension: 100 )!.absoluteString
            self.dismiss(animated: true, completion: nil)
          let picUrl = user.profile.imageURL(withDimension: 100)
           
                self.insertApiCall(email: user.profile.email, name: user.profile.name, picUrl: "abc" , DeviceToken: "", Gender: "", CellNumber: "", TrackId: "", ID: user.userID)
            
         
            self.createGroupApiCall(Grp_name: user.profile.name, Grp_Pic: "", Group_Desc: "", socialID:user.userID!)
//
//
            if(self.ChangeScreen_StatusArray[ChangeScreen_Status!] ){
            let internVC = self.storyboard?.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
            self.present(internVC, animated: true, completion: nil)
        }
     
        }
    }
    
}

