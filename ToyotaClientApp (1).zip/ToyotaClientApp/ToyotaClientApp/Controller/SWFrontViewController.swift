//
//  SWFrontViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 29/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController
import GoogleMaps

class SWFrontViewController: UIViewController {
    
    //MARK: Gloabl Variables
    let status = CLLocationManager.authorizationStatus()
    var locationManager = CLLocationManager()
    var camera:GMSCameraPosition?
     var maker1 = GMSMarker()
    
    var popUpView = AddCarPopUpViewController.instanceFromNib()
    
    //MARK: - Outlets
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var Btn_AddCar: UIButton!
    
    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if self.revealViewController() != nil {
            
            MenuButton.target = self.revealViewController()
            MenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            
            self.navigationItem.title = "Home"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            self.Btn_AddCar.cornerRadius = 0.5 * Btn_AddCar.frame.width
            
       //location
            self.mapView.delegate = self
            
            locationManager.delegate = self
            
            locationManager.requestAlwaysAuthorization()
            
            self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            
        }
    }
    override func viewDidAppear(_ animated: Bool) {
          self.locationManager.startUpdatingLocation()
    }
    
    //MARK: - Actions
    
    @IBAction func AddCar(_ sender: Any) {
        showPopUp()
      //  self.popUpView.dismissView.addTarget(self, action: #selector(self.dismissDialogue(_:)), for: .touchUpInside)
    }
    
    //MARK: - Functions
    
    func showPopUp()
    {
        self.popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
            popUpView.txt_Email.title = "Email"
             popUpView.txt_Email.placeholder = "Email"
               popUpView.txt_Password.placeholder = "Password"
                popUpView.txt_Password.title = "Password"
        self.popUpView.Btn_Cancel.addTarget(self, action: #selector(self.dismissDialogue(_:)), for: .touchUpInside)
        self.popUpView.Btn_Add.addTarget(self, action: #selector(self.Add_Car(_:)), for: .touchUpInside)
        self.view.addSubview(self.popUpView)
        
        
    }
    @objc func dismissDialogue(_ sender: UIButton)
    {
        self.popUpView.removeFromSuperview()
    }
    
    @objc func Add_Car(_ sender: UIButton)
    {
        // Add Car Code
    }
    func showCurrentLocation(){
        
        camera = GMSCameraPosition.camera(withLatitude: (self.locationManager.location?.coordinate.latitude)!, longitude: (self.locationManager.location?.coordinate.longitude)!, zoom: 15)
        mapView.camera = camera!
        
        mapView.settings.myLocationButton = true
       // mapView.isMyLocationEnabled = true
        
        
        
    }
   
        
    }
    
    // for Turning on location of phone if off currently
    




extension SWFrontViewController:CLLocationManagerDelegate,GMSMapViewDelegate{
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        print(locationManager.location?.coordinate)
//        var maker1 = GMSMarker()
//        maker1.icon = GMSMarker.markerImage(with: UIColor.gray)
//        maker1.map = mapView
//       showCurrentLocation()
////        CheckEnterAndExitRegion()
//
//    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
                print(locationManager.location?.coordinate)
        
              //  maker1.icon = GMSMarker.markerImage(with: UIColor.gray)
//        maker1.icon?.images = UIImage(named: "nav_trip")
        maker1.icon = UIImage(named: "nav_trip")
        maker1.position = manager.location!.coordinate
                maker1.map = mapView
               showCurrentLocation()
    }
    func createSettingsAlertController(title: String, message: String) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)
        let settingsAction = UIAlertAction(title: NSLocalizedString("Settings", comment: ""), style: .default) { (UIAlertAction) in
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)! as URL, options: [:], completionHandler: nil)
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(settingsAction)
        self.present(alertController, animated: true, completion: nil)
        
    }
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways && status == .authorizedWhenInUse {
            
        }
        else if status == .notDetermined {
            return
        }
        else  if status == .denied || status == .restricted {
            self.createSettingsAlertController(title: "Turn on location", message: "open settings to turn on your location")
        }
        
}
}
