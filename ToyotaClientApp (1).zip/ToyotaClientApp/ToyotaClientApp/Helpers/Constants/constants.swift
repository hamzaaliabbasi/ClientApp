//
//  constants.swift
//  ToyotaClientApp
//
//  Created by Saad Muhammad Khan on 12/07/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
struct Constants {
    
    
//    static let APP_DELEGATE                =  UIApplication.shared.delegate as! AppDelegate
//   static let UIWINDOW                    =  UIApplication.shared.delegate!.window!
    static let USER_DEFAULTS               = UserDefaults.standard
    static let ServerDateFormat            = "yyyy-MM-dd'T'HH:mm:ss"
    //  static let BaseURL                     = "http://portal.tpllife.com:9040/"  // Live base URL
    //   static let BaseURL             = "http://portal.tpllife.com:8040/" // Local base url
    static let BaseURL = "http://103.9.23.45/"   //PUBLIC UAT tEST
    static let apiString = "api"
   
    

}
