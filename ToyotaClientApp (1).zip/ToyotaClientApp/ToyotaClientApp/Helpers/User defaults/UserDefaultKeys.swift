

import Foundation

struct UserDefaultsKeys {
    static let User = "User_Obj"
    static let Email = "email"
    static let picUrl = "PicUrl"
    static let Gender = "Gender"
    static let CellNumber = "CellNumber"
    static let UserName = "Name"
    static let status = "Status"
    static let SocialID = "Social_ID"
    static let trackID = "Track_ID"
    
    
    static let forgotPasswordUserID = "forgotPasswordUserID"
    static let forgotPasswordCode = "forgotPasswordCode"
    
//    static let showOnBoardingScreens = "showOnBoardingScreens"
//    static let isTripInsuranceUserRegistered = "UserTripInsuranceRegistered"
}
