//
//  NotificationTableViewCell.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 26/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class NotificationTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    @IBOutlet weak var img_logo: UIImageView!
    @IBOutlet weak var lab_details: UILabel!
    @IBOutlet weak var lab_date: UILabel!
    @IBOutlet weak var lab_time: UILabel!
    @IBOutlet weak var lab_tc: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
       // self.img_logo.cornerRadius = self.img_logo.frame.width * 0.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
